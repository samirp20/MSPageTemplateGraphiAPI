[CmdletBinding()]
param (
    [Parameter(Mandatory=$true)]
    [string]
    $SiteUrl,
    [Parameter(Mandatory=$true)]
    [string]
    $PageTemplate,
    [Parameter(Mandatory=$true)]
    [string]
    $OutputFile
)
#Connect-MgGraph -Scopes Sites.ReadWrite.All

try {
    $uri = [uri]::new($SiteUrl)
    $siteUrlForGraph = "$($uri.Authority):$($uri.AbsolutePath)"
    
    $site = Get-MgSite -siteid $siteUrlForGraph
    $siteId = $site.Id
    
    $requestUri = "https://graph.microsoft.com/beta/sites/$($siteId)/pageTemplates/microsoft.graph.pageTemplate?`$expand=canvasLayout&`$filter=name eq '$($PageTemplate)'"
    $headers = @{
        Accept = "application/json;odata.metadata=none"
    }
    $result = Invoke-MgGraphRequest -Method GET -Uri $requestUri -Headers $headers
    
    if (!$result -or !$result.value -or $result.value.Count -eq 0)
    {
        Write-Warning "Template not found. Exiting..."
        return
    }
    
    $template = $result.value[0]
    
    
    Set-Content -Value (ConvertTo-Json $template -Depth 20) -Path $OutputFile
}
catch 
{
    Write-Error $_.Exception.Message    
}
finally 
{
    #Disconnect-MgGraph
}
