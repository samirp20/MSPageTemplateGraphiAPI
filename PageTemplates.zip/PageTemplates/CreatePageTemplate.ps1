[CmdletBinding()]
param (
    [Parameter(Mandatory=$true)]
    [string]
    $SiteUrl,
    [Parameter(Mandatory=$true)]
    [string]
    $InputFile
)
#Connect-MgGraph -Scopes Sites.ReadWrite.All
try 
{
    $input = Get-Content $InputFile -Raw
    $template = ConvertFrom-Json $input

    $uri = [uri]::new($SiteUrl)
    $siteUrlForGraph = "$($uri.Authority):$($uri.AbsolutePath)"
    
    $site = Get-MgSite -siteid $siteUrlForGraph
    $siteId = $site.Id

    $canvasLayout = [PSCustomObject]@{

    }

    $newTemplate = [PSCustomObject]@{
        "@odata.type" = "#microsoft.graph.pageTemplate"
        name =  $template.name
        title = $template.name
        pageLayout = "article"
        canvasLayout = $template.canvasLayout
    }
    
    $requestUri = "https://graph.microsoft.com/beta/sites/$($siteId)/pageTemplates/microsoft.graph.pageTemplate"
    $result = Invoke-MgGraphRequest -Method POST -Uri $requestUri -Body (ConvertTo-Json $newTemplate -Depth 20)

    # $requestUri = "https://graph.microsoft.com/beta/sites/$($siteId)/pageTemplates/microsoft.graph.pageTemplate"
    # $result = Invoke-MgGraphRequest -Method POST -Uri $requestUri -ContentType "application/json" -Body 
}
catch 
{
    Write-Error $_.Exception.Message    
}
finally 
{
    #Disconnect-MgGraph
}